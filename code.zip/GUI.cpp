/*
#include <windows.h>
#include <string>
#include <stdlib.h>
#include <iostream>


#define AJOUTER 100
#define LANCER 101
#define IDC_COMBOBOX_TEXT 1000
#define IDC_COMBOBOX_TEXT2 1001
#define IDC_COMBOBOX_TEXT3 1002

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

void AddControls(HWND);

HWND hType;
HWND hR;
HWND hCX;
HWND hCY;
HWND hCZ;

HWND hCombo;
HWND hCombo2;
HWND hCombo3;

HINSTANCE g_hinst;

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE pr, LPSTR args, int ncmdshow) {

	std::string s("123");
	std::wstring stemp = std::wstring(s.begin(), s.end());
	LPCWSTR sw = stemp.c_str();

	WNDCLASSW wc = { 0 };

	wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hInstance = hInst;
	wc.lpszClassName = L"FenetrePrincipale";
	wc.lpfnWndProc = WindowProcedure;
	g_hinst = hInst;

	if (!RegisterClassW(&wc)) {
		return -1;
	}

	CreateWindowW(L"FenetrePrincipale", L"CONSTRUCTEUR DE LA SCENE", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 100, 100, 420, 530, NULL, NULL, NULL, NULL);

	MSG msg = { 0 };

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;

}
const TCHAR* items[] = { TEXT("Sphere"), TEXT("Cube"), TEXT("Plan") };
LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {

	switch (msg) {
	case WM_COMMAND:
		switch(wp)
		{
		case AJOUTER:
			wchar_t X[10];
			wchar_t Y[10];
			wchar_t Z[10];
			wchar_t R[10];
			wchar_t type[10];
			wchar_t mat[10];
			wchar_t col[20];
			GetWindowTextW(hCX, X, 10);
			GetWindowTextW(hCY, Y, 10);
			GetWindowTextW(hCZ, Z, 10);
			GetWindowTextW(hR, R, 10);
			GetWindowTextW(hCombo, type, 10);
			GetWindowTextW(hCombo2, mat, 10);
			GetWindowTextW(hCombo3, col, 20);

			//create();

			break;
		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_CREATE:
	{
		AddControls(hWnd);

	}
	break;

	default:
		return DefWindowProcW(hWnd, msg, wp, lp);
	}

}

void AddControls(HWND hWnd) {

	CreateWindowW(L"Static", L"Choisir la figure : ", WS_VISIBLE | WS_CHILD, 50, 50, 155, 20, hWnd, NULL, NULL, NULL);
	//hType = CreateWindowW(L"Edit", L"Sphere", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 50 + 155 + 5, 50, 136, 20, hWnd, NULL, NULL, NULL);
	hCombo = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 50, 140, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Sphere");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Cube");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Plan");
	SendMessage(hCombo, CB_SETCURSEL, (WPARAM)0, 0);


	CreateWindowW(L"Static", L"Choisir le materiau : ", WS_VISIBLE | WS_CHILD, 50, 50+50+10, 155, 20, hWnd, NULL, NULL, NULL);
	hCombo2 = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 50 + 50 + 10, 140, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT2, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Metal");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Verre");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Pierre");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Source lumineuse");
	SendMessage(hCombo2, CB_SETCURSEL, (WPARAM)0, 0);
	
	CreateWindowW(L"Static", L"Choisir la couleur : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50 + 50 + 10, 155, 20, hWnd, NULL, NULL, NULL);
	hCombo3 = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 60 + 50 + 50 + 10, 140, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT3, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Bleu");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Jaune");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Brun");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Orange");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Rouge");
	SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Blanc (transperent)");
	SendMessage(hCombo3, CB_SETCURSEL, (WPARAM)0, 0);

	CreateWindowW(L"Static", L"Saisir la taille (radius) : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50+50+50+10+10, 155, 20, hWnd, NULL, NULL, NULL);
	hR =  CreateWindowW(L"Edit", L"0.5", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 50 + 155 + 5, 60 + 50 + 50 + 50 + 10 + 10, 136, 20, hWnd, NULL, NULL, NULL);

	CreateWindowW(L"Static", L"Saisir le centre : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Static", L"x =", WS_VISIBLE | WS_CHILD, 30 + 155 + 2, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Static", L"y =", WS_VISIBLE | WS_CHILD, 30 + 155 + 2 + 55, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Static", L"z =", WS_VISIBLE | WS_CHILD, 30 + 155 + 2 + 110, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
	hCX =  CreateWindowW(L"Edit", L"0", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 30 + 155 + 2 + 23, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 25, 20, hWnd, NULL, NULL, NULL);
	hCY =  CreateWindowW(L"Edit", L"0", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 30 + 155 + 2 + 23 + 55, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 25, 20, hWnd, NULL, NULL, NULL);
	hCZ =  CreateWindowW(L"Edit", L"-1", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 30 + 155 + 2 + 23 + 110, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 25, 20, hWnd, NULL, NULL, NULL);

	CreateWindowW(L"Button", L"Ajouter", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 125, 100 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 155, 30, hWnd, (HMENU) AJOUTER, NULL, NULL);

	CreateWindowW(L"Button", L"Lancer", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 125, 110 + 100 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 155, 40, hWnd, (HMENU) LANCER, NULL, NULL);


}*/