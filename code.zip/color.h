#pragma once
#ifndef COLOR_H
#define COLOR_H

#include "vec3.h"
#include "images.h"

#include <iostream>
inline double clamp(double x, double min, double max) {
    if (x < min) return min;
    if (x > max) return max;
    return x;
}
void write_color(color pixel_color, int samples_per_pixel, Pixel* pix) {
    auto r = pixel_color.x();
    auto g = pixel_color.y();
    auto b = pixel_color.z();

    // Divide the color by the number of samples.
    auto scale = 1.0 / samples_per_pixel;
    r *= scale;
    g *= scale;
    b *= scale;

    // Write the translated [0,255] value of each color component.
    pix->red = 256 * clamp(r, 0.0, 0.999);
    pix->green = 256 * clamp(g, 0.0, 0.999);
    pix->blue = 256 * clamp(b, 0.0, 0.999);

    /*
    out << static_cast<int>(pix->red) << ' '
        << static_cast<int>(pix->green) << ' '
        << static_cast<int>(pix->blue) << '\n';
        */
}

#endif

