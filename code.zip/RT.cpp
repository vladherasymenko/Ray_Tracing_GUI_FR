﻿#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <chrono>
#include <string>
#include <omp.h>
#include <vector>

#include "color.h"
#include "hittable.h"
#include "hittable_list.h"

#include "camera.h"

#include "color.h"
#include "ray.h"
#include "vec3.h"
#include "material.h"
#include "texture.h"
#include "Rectangle.h"

#include "images.h"

#include <Windows.h>
#include <windowsx.h>

#define AIDE 10
#define TEX_SOURCE 11
#define MET_VERRE 12
#define SPH_VIDE 13
#define TOUT_SUP 14

#define AJOUTER 100
#define AJOUTER 100
#define AJOUTER 100
#define AJOUTER 100
#define LANCER 101
#define TOUT_SUPPRIMER 102

#define T_225 200
#define T_450 201
#define T_900 202
#define T_1800 203

#define IDC_COMBOBOX_TEXT 1000
#define IDC_COMBOBOX_TEXT2 1001
#define IDC_COMBOBOX_TEXT3 1002

int image_width = 220;
auto aspect_ratio = 1;//16.0 / 9.0;
int image_height = image_width;//(int)(image_width / aspect_ratio);
color background = color(0.53, 0.81, 0.92);

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

void AddControls(HWND);
void AddMenus(HWND);
void LoadImages(LPCWSTR name);

DWORD WINAPI create(LPVOID lpParameter);

color ray_color(const ray& r, const color& background, const hittable& world, int depth);

HWND hType;
HWND hR;
HWND hCX;
HWND hCY;
HWND hCZ;
HWND hButton_ajouter;
HWND hButton_lancer;
HWND hButton_supprimer;
HWND hwndPB;

HWND hCombo;
HWND hCombo2;
HWND hCombo3;
HWND hContenu;

HWND hImage;

HBITMAP bitImage;

HMENU hMenu;

HINSTANCE g_hinst;

hittable_list world;

using namespace std;

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE pr, LPSTR args, int ncmdshow) {

    std::string s("123");
    std::wstring stemp = std::wstring(s.begin(), s.end());
    LPCWSTR sw = stemp.c_str();

    WNDCLASSW wc = { 0 };

    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hInstance = hInst;
    wc.lpszClassName = L"FenetrePrincipale";
    wc.lpfnWndProc = WindowProcedure;
    g_hinst = hInst;

    if (!RegisterClassW(&wc)) {
        return -1;
    }

    CreateWindowW(L"FenetrePrincipale", L"CONSTRUCTEUR DE LA SCÈNE", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 210, 110, 740, 660, NULL, NULL, NULL, NULL);

    MSG msg = { 0 };

    while (GetMessage(&msg, NULL, NULL, NULL)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;

}

std::string wchar_to_str(wchar_t* w_str) {
    wstring ws(w_str);
    std::string str(ws.begin(), ws.end());
    remove(str.begin(), str.end(), ' ');

    return str;
}

float wchar_to_float(wchar_t* w_str) {
    wstring ws(w_str);
    std::string str(ws.begin(), ws.end());
    remove(str.begin(), str.end(), ' ');

    return std::stof(str);
}

bool isEnabled = true;
//const TCHAR* items[] = { TEXT("Sphere") }; //, TEXT("Cube"), TEXT("Plan")
LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {

    switch (msg) {
    case WM_COMMAND:
        if(HIWORD(wp) == CBN_SELENDOK) {
            int selection = SendMessage(hCombo2, CB_GETCURSEL, NULL, NULL);
                if ((selection == 1 || selection == 3) && isEnabled) {
                    EnableWindow(hCombo3, false);
                    UpdateWindow(hCombo3);
                    isEnabled = false;
                    SendMessage(hCombo3, CB_SETCURSEL, (WPARAM)5, 0);
                }
                if (selection != 1 && selection != 3 && isEnabled == false) {
                    EnableWindow(hCombo3, true);
                    UpdateWindow(hCombo3);
                    isEnabled = true;
                    SendMessage(hCombo3, CB_SETCURSEL, (WPARAM)0, 0);
                }

        }
        switch (wp)
        {
        case AIDE: { 
            
            MessageBox(NULL, L"-Ajoutez des nouveaux éléments dans le plan en choisissant les paramètres souhaités et en appuyant le boutton 'Ajouter'\n-Puis, lancez la generation en appuyant 'Lancer'\n-Pour supprimer tous les éléments ajoutés, clickez 'Tout supprimer'\n\nLe caméra se trouve dans le point (0, 0, 0) et est focalisé sur le plan D:{(x, y, z) | (x, y)  є R2 & z = -1} [Donc, le plan z = -1] \n\n Vous pouvez aussi changer la taille de l'image en choisissant l'option 'Changer la taille'", L"Aide", MB_OK);

            break; }
        case TEX_SOURCE: { 
            background = color(0.0, 0.0, 0.0);
            world = propre_image();
            auto checker = make_shared<checker_texture>(color(0.2, 0.3, 0.1), color(0.9, 0.9, 0.9));
            world.add(make_shared<sphere>(point3(0, -100, 0), 99.5, make_shared<diffuse>(checker)));

            auto mat = make_shared<metal>(color(1.0, 0.0, 0.0));
            world.add(make_shared<sphere>(point3(-0.4, -0.45, -0.7), 0.05, mat));

            auto mat1 = make_shared<metal>(color(0.1, 0.2, 0.8));
            world.add(make_shared<sphere>(point3(0.4, -0.45, -0.7), 0.05, mat1));

            auto mat2 = make_shared<metal>(color(0.65, 0.15, 0.15));
            world.add(make_shared<sphere>(point3(0, -0.45, -0.6), 0.05, mat2));

            auto difflight = make_shared<diffuse_light>(color(4, 4, 4));
            //world.add(make_shared<sphere>(point3(0, 0, 2), 1.5, difflight));

            world.add(make_shared<sphere>(point3(0, 4.2, -1), 2.5, difflight));
            break; }
        case MET_VERRE: { 

            background = color(0.53, 0.81, 0.92);

            auto mat = make_shared<dielectric>(1.5);
            world.add(make_shared<sphere>(point3(0, 0, -1), 0.5, mat));

            auto mat2 = make_shared<diffuse>(color(0.1, 0.2, 0.8));
            world.add(make_shared<sphere>(point3(0, -100, 0), -99.5, mat2));

            //auto mat3 = make_shared<metal>(color(1.0, 1.0, 1.0));
            //world.add(make_shared<sphere>(point3(0, -0.2, -2), 0.3, mat3));

            auto mat4 = make_shared<metal>(color(0.0, 0.0, 1.0));
            world.add(make_shared<sphere>(point3(-1, 0, -1), 0.5, mat4));

            auto mat5 = make_shared<metal>(color(1.0, 0.0, 0.0));
            world.add(make_shared<sphere>(point3(1, 0, -1), 0.5, mat5));

            break; }
        case SPH_VIDE: { 
            background = color(0.53, 0.81, 0.92);

            auto mat = make_shared<dielectric>(1.5);
            world.add(make_shared<sphere>(point3(0, 0, -1), -0.5, mat));

            auto mat2 = make_shared<diffuse>(color(0.8, 0.2, 0.2));
            world.add(make_shared<sphere>(point3(0, -100, 0), -99.5, mat2));

            auto propre_texture = make_shared<image_texture>("earthmap.jpg");
            auto propre_surface = make_shared<diffuse>(propre_texture);
            world.add(make_shared<sphere>(point3(0, 0, -1), 0.3, propre_surface));

            auto mat4 = make_shared<metal>(color(0.0, 0.0, 1.0));
            world.add(make_shared<sphere>(point3(-1, 0, -1), 0.5, mat4));

            auto mat5 = make_shared<metal>(color(1.0, 1.0, 1.0));
            world.add(make_shared<sphere>(point3(1, 0, -1), 0.5, mat5));
            
            break; }

        case TOUT_SUPPRIMER:
        {
            world.clear();
            break;
        }
        case T_225:
        {
            image_width = 220;
            image_height = 220;
            DestroyWindow(hwndPB);
            hwndPB = CreateWindowEx(0, L"msctls_progress32", (LPTSTR)NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 25 + 90 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 633, 30, hWnd, (HMENU)0, g_hinst, NULL);
            SendMessage(hwndPB, (WM_USER + 4), (WPARAM)1, 0);
            break;
        }
        case T_450:
        {
            image_width = 440;
            image_height = 440;
            DestroyWindow(hwndPB);
            hwndPB = CreateWindowEx(0, L"msctls_progress32", (LPTSTR)NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 25 + 90 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 633, 30, hWnd, (HMENU)0, g_hinst, NULL);
            SendMessage(hwndPB, (WM_USER + 1), 0, MAKELPARAM(0, image_height));
            SendMessage(hwndPB, (WM_USER + 4), (WPARAM)1, 0);
            break;
        }
        case T_900:
        {
            image_width = 880;
            image_height = 880;
            DestroyWindow(hwndPB);
            hwndPB = CreateWindowEx(0, L"msctls_progress32", (LPTSTR)NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 25 + 90 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 633, 30, hWnd, (HMENU)0, g_hinst, NULL);
            SendMessage(hwndPB, (WM_USER + 1), 0, MAKELPARAM(0, image_height));
            SendMessage(hwndPB, (WM_USER + 4), (WPARAM)1, 0);
            break;
        }
        case T_1800:
        {
            image_width = 1760;
            image_height = 1760;
            DestroyWindow(hwndPB);
            hwndPB = CreateWindowEx(0, L"msctls_progress32", (LPTSTR)NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 25 + 90 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 633, 30, hWnd, (HMENU)0, g_hinst, NULL);
            SendMessage(hwndPB, (WM_USER + 1), 0, MAKELPARAM(0, image_height));
            SendMessage(hwndPB, (WM_USER + 4), (WPARAM)1, 0);

            break;
        }
        case AJOUTER:
        {
            wchar_t X[10];
            wchar_t Y[10];
            wchar_t Z[10];
            wchar_t R[10];
            
            wchar_t type[10];
            wchar_t mat[10];
            wchar_t col[20];

            GetWindowTextW(hCX, X, 10);
            GetWindowTextW(hCY, Y, 10);
            GetWindowTextW(hCZ, Z, 10);
            GetWindowTextW(hR, R, 10);

            GetWindowTextW(hCombo, type, 10);
            GetWindowTextW(hCombo2, mat, 10);
            GetWindowTextW(hCombo3, col, 20);

            float x, y, z, r;
            try { 
                x = wchar_to_float(X);
                y = wchar_to_float(Y);
                z = wchar_to_float(Z);
                r = wchar_to_float(R);
            }
            catch (...) { 
                MessageBox(hWnd, L"Veuillez entrer uniquement des valeurs numériques", L"Erreur", MB_OK);
                break;
            }

            
            point3 centre(x, y, z);

            // World
            std::string str_mat = wchar_to_str(mat);
            std::string couleur = wchar_to_str(col);
            color couleur_figure = color(1.0, 1.0, 1.0);
            if (couleur == "Bleu") {
                couleur_figure = (color(0.1, 0.2, 0.8));
            }
            if (couleur == "Vert") {
                couleur_figure = (color(0.0, 1.0, 0.0));
            }
            if (couleur == "Noir") {
                couleur_figure = (color(0.0, 0.0, 0.0));
            }
            else if (couleur == "Jaune") {
                couleur_figure = (color(1, 1, 0));
            }
            else if (couleur == "Brun") {
                couleur_figure = (color(0.65, 0.15, 0.15));
            }
            else if (couleur == "Orange") {
                couleur_figure = (color(1.0, 0.65, 0.0));
            }
            else if (couleur == "Rouge") {
                couleur_figure = (color(1.0, 0.0, 0.0));
            }
            else if (couleur == "Blanc (transperent)") {
                couleur_figure = (color(0.9, 0.9, 0.9));
            } 

            if (str_mat == "Metal") {
                auto mat = make_shared<metal>(couleur_figure);
                world.add(make_shared<sphere>(centre, r, mat));
            }
            else if (str_mat == "Verre") {
                auto mat = make_shared<dielectric>(1.5);
                world.add(make_shared<sphere>(centre, r, mat));
            }
            else if (str_mat == "Pierre") {
                auto mat = make_shared<diffuse>(couleur_figure);
                world.add(make_shared<sphere>(centre, r, mat));
            }
            else if (str_mat == "Source lumineuse") {
                auto mat = make_shared<diffuse_light>(color(4, 4, 4));
                break;
            }
            else if (str_mat == "Texture") {
                MessageBox(NULL, L"WIP", L"Merci d'avoir patiente", MB_OK);
                break;
            }
            
            wstring ws(X);
            std::string str_x(ws.begin(), ws.end());
            remove(str_mat.begin(), str_mat.end(), ' ');

            break;
        }
        case LANCER:

            HANDLE hThread = CreateThread(NULL, 0, create, NULL, 0, NULL);
            break;
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_CREATE:
    {
        LoadImages(L"default.bmp");
        AddMenus(hWnd);
        AddControls(hWnd);
        break;
    }
    
    
    case 100501: 
    {
        //LoadImages(L"image.bmp");
        bitImage = (HBITMAP)LoadImageW(NULL, L"image.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
        DestroyWindow(hImage);
        hImage = CreateWindowW(L"Static", L"123", WS_VISIBLE | WS_CHILD | SS_BITMAP | WS_BORDER | SS_REALSIZECONTROL, 450, 80, 230, 230, hWnd, NULL, NULL, NULL);
        SendMessageW(hImage, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)bitImage);
    }

    default:
        return DefWindowProcW(hWnd, msg, wp, lp);
    }

}

void AddControls(HWND hWnd) {

    CreateWindowW(L"Static", L"Choisir la figure : ", WS_VISIBLE | WS_CHILD, 50, 50, 155, 20, hWnd, NULL, NULL, NULL);
    //hType = CreateWindowW(L"Edit", L"Sphere", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 50 + 155 + 5, 50, 136, 20, hWnd, NULL, NULL, NULL);
    hCombo = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 50, 170, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Sphere");
    //SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Cube");
    //SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT), CB_ADDSTRING, 0, (LPARAM)L"Plan");
    SendMessage(hCombo, CB_SETCURSEL, (WPARAM)0, 0);

    CreateWindowW(L"Static", L"Choisir le matériau : ", WS_VISIBLE | WS_CHILD, 50, 50 + 50 + 10, 155, 20, hWnd, NULL, NULL, NULL);
    hCombo2 = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 50 + 50 + 10, 170, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT2, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Metal");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Verre");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Pierre");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Source lumineuse");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT2), CB_ADDSTRING, 0, (LPARAM)L"Texture");
    
    SendMessage(hCombo2, CB_SETCURSEL, (WPARAM)0, 0);

    CreateWindowW(L"Static", L"Choisir la couleur : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50 + 50 + 10, 155, 20, hWnd, NULL, NULL, NULL);
    hCombo3 = CreateWindow(L"COMBOBOX", NULL, WS_VISIBLE | WS_CHILD | CBS_DROPDOWN | SS_CENTER, 50 + 155 + 5, 60 + 50 + 50 + 10, 170, 800, hWnd, (HMENU)IDC_COMBOBOX_TEXT3, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);

    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Bleu");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Jaune");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Brun");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Orange");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Rouge");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Blanc (transperent)");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Noir");
    SendMessage(GetDlgItem(hWnd, IDC_COMBOBOX_TEXT3), CB_ADDSTRING, 0, (LPARAM)L"Vert");
    SendMessage(hCombo3, CB_SETCURSEL, (WPARAM)0, 0);

    CreateWindowW(L"Static", L"Saisir la taille (radius) : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50 + 50 + 50 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
    hR = CreateWindowW(L"Edit", L"0.5", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 50 + 155 + 5, 60 + 50 + 50 + 50 + 10 + 10, 166, 20, hWnd, NULL, NULL, NULL);

    CreateWindowW(L"Static", L"Saisir le centre : ", WS_VISIBLE | WS_CHILD, 50, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 155, 20, hWnd, NULL, NULL, NULL);
    CreateWindowW(L"Static", L"x =", WS_VISIBLE | WS_CHILD, 30 + 155 + 2, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 20, 20, hWnd, NULL, NULL, NULL);
    CreateWindowW(L"Static", L"y =", WS_VISIBLE | WS_CHILD, 30 + 155 + 12 + 55, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 20, 20, hWnd, NULL, NULL, NULL);
    CreateWindowW(L"Static", L"z =", WS_VISIBLE | WS_CHILD, 30 + 155 + 22 + 110, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 20, 20, hWnd, NULL, NULL, NULL);
    hCX = CreateWindowW(L"Edit", L"0", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER  , 30 + 155 + 2 + 23, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 35, 20, hWnd, NULL, NULL, NULL);
    hCY = CreateWindowW(L"Edit", L"0", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER , 30 + 155 + 12 + 23 + 55, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 35, 20, hWnd, NULL, NULL, NULL);
    hCZ = CreateWindowW(L"Edit", L"-1",WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER , 30 + 155 + 22 + 23 + 110, 60 + 50 + 50 + 50 + 50 + 10 + 10 + 10, 35, 20, hWnd, NULL, NULL, NULL);

    CreateWindowW(L"Static", L"Contenu de la scène", WS_VISIBLE | WS_CHILD | SS_CENTER, 450, 50, 232, 20, hWnd, NULL, NULL, NULL);

    hImage = CreateWindowW(L"Static", L"", WS_VISIBLE | WS_CHILD | SS_BITMAP | WS_BORDER, 450, 80, 230, 230, hWnd, NULL, NULL, NULL);
    SendMessageW(hImage, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM) bitImage);

    hwndPB = CreateWindowEx(0, L"msctls_progress32", (LPTSTR)NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 25+90 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 633, 30, hWnd, (HMENU)0, g_hinst, NULL);

    SendMessage(hwndPB, (WM_USER + 1), 0, MAKELPARAM(0, image_height));

    SendMessage(hwndPB, (WM_USER+4), (WPARAM)1, 0);

    hButton_ajouter = CreateWindowW(L"Button", L"Ajouter", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 300, 25 + 50+100 + 50 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 155, 30, hWnd, (HMENU)AJOUTER, NULL, NULL);

    hButton_lancer = CreateWindowW(L"Button", L"Lancer", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 300, 25 + 50+110 + 100 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 155, 30, hWnd, (HMENU)LANCER, NULL, NULL);

    hButton_supprimer = CreateWindowW(L"Button", L"Tout supprimer", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 300, 60+25 + 50 + 110 + 100 + 50 + 50 + 50 + 10 + 10 + 20 + 10, 155, 30, hWnd, (HMENU)TOUT_SUPPRIMER, NULL, NULL);
}


void AddMenus(HWND hWnd) {
    hMenu = CreateMenu();
    HMENU hConfiguration = CreateMenu();
    HMENU hScenePredef = CreateMenu();
    HMENU hTaille = CreateMenu();

    AppendMenu(hConfiguration, MF_POPUP, (UINT_PTR)hScenePredef, L"Choisir une scène prédéfinie");
    AppendMenu(hConfiguration, MF_POPUP, (UINT_PTR)hTaille, L"Changer la taille de l'image");
    AppendMenu(hConfiguration, MF_STRING, TOUT_SUPPRIMER, L"Tout supprimer");

    AppendMenu(hScenePredef, MF_STRING, TEX_SOURCE, L"Textures et source lumineuse");
    AppendMenu(hScenePredef, MF_STRING, MET_VERRE, L"Métal et verre");
    AppendMenu(hScenePredef, MF_STRING, SPH_VIDE, L"Sphère vide en verre");

    AppendMenu(hTaille, MF_STRING, T_225, L"225x225");
    AppendMenu(hTaille, MF_STRING, T_450, L"450x450");
    AppendMenu(hTaille, MF_STRING, T_900, L"900x900");
    AppendMenu(hTaille, MF_STRING, T_1800, L"1800x1800");

    AppendMenu(hMenu, MF_POPUP, (UINT_PTR) hConfiguration, L"Configurer la scène");
    AppendMenu(hMenu, MF_STRING, AIDE, L"Aide");

    SetMenu(hWnd, hMenu);
}

void LoadImages(LPCWSTR name) {
    bitImage = (HBITMAP) LoadImageW(NULL, name, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
}

color ray_color(const ray& r, const color& background, const hittable& world, int depth) {
    hit_record rec;

    // If we've exceeded the ray bounce limit, no more light is gathered.
    if (depth <= 0)
        return color(0, 0, 0);

    // If the ray hits nothing, return the background color.
    if (!world.hit(r, 0.001, infinity, rec))
        return background;

    ray scattered;
    color attenuation;
    color emitted = rec.mat_ptr->emitted(rec.u, rec.v, rec.p);

    if (!rec.mat_ptr->scatter(r, rec, attenuation, scattered))
        return emitted;

    return emitted + attenuation * ray_color(scattered, background, world, depth - 1);
}

DWORD WINAPI create(LPVOID lpParameter) {
    EnableWindow(hButton_ajouter, false);
    EnableWindow(hButton_lancer, false);
    EnableWindow(hButton_supprimer, false);
    UpdateWindow(hButton_ajouter);
    UpdateWindow(hButton_lancer);
    UpdateWindow(hButton_supprimer);

    size_t numberOfPixels = image_width * image_height;
    Pixel* pixels_tableau;
    pixels_tableau = (Pixel*)malloc(numberOfPixels * sizeof(Pixel));


    //ofstream f;
    //f.open("image.ppm"); // image - format ppm 
    //f << "P3\n" << image_width << ' ' << image_height << "\n255\n"; 

    ofstream fout("image.bmp", ios::binary); // image - format bmp 
    bmpInfoHeader.width = image_width;
    bmpInfoHeader.height = image_height;
    bmpHeader.save_on_file(fout);
    bmpInfoHeader.save_on_file(fout);


    // Image
    const int samples_per_pixel = 650;

    // Camera
    camera cam(90.0, aspect_ratio);

    // Render
    int m_depth = 150;

    omp_set_num_threads(8);
    #pragma omp parallel for collapse(3) schedule(dynamic)
    for (int j = image_height - 1; j >= 0; --j) {
        SendMessage(hwndPB, (WM_USER + 5), 0, 0);
        for (int i = 0; i < image_width; ++i) {
            color pixel_color(0, 0, 0);
            //#pragma omp parallel for
            for (int s = 0; s < samples_per_pixel; ++s) {
                auto u = (i + random_double()) / (image_width - 1);
                auto v = (j + random_double()) / (image_height - 1);
                ray r = cam.get_ray(u, v);
                pixel_color += ray_color(r, background, world, m_depth);
               
            }
            Pixel pixel;

            write_color(pixel_color, samples_per_pixel, &pixel);
            pixels_tableau[i + j* image_height] = pixel;
        }
    }
    //f.close();
    
    for (int i = 0; i < numberOfPixels; i++) {
        pixels_tableau[i].save_on_file(fout);
    }
    
    fout.close();

    EnableWindow(hButton_ajouter, true);
    EnableWindow(hButton_lancer, true);
    EnableWindow(hButton_supprimer, true);
    UpdateWindow(hButton_ajouter);
    UpdateWindow(hButton_lancer);
    UpdateWindow(hButton_supprimer);
    

    PostMessage(HWND_BROADCAST, 100501, 0, 0);
    MessageBox(NULL, L"Votre image a été aussi sauvegardée dans le ficher 'image.bmp'", L"Merci d'avoir patienté", MB_OK);

    return 0;
}
