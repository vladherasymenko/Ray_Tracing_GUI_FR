#pragma once

// // L'inclusion de SDKDDKVer.h définit la version de plateforme Windows la plus haute disponible.
// Si vous voulez générer votre application pour une plateforme Windows précédente, incluez WinSDKVer.h et
// définissez la macro _WIN32_WINNT sur la plateforme à prendre en charge avant d'inclure SDKDDKVer.h.
#include <SDKDDKVer.h>
